import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.paprandomteam.prtcreatorhub',
  appName: 'PRT CREATOR HUB',
  webDir: 'www',
  server: {
    url: 'https://paprandom-team.freesrv.com',
    cleartext: false,
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false
  }
};

export default config;
