# PRT CREATOR HUB — Android APK

Android wrapper resmi untuk **PRT CREATOR HUB**.

## Cara kerja
APK ini membuka web PRT yang berjalan di server:

`https://paprandom-team.freesrv.com`

Database, Google Drive, Asset Library, Admin, Live & Social, WRS, YouTube, dan autentikasi tetap berada di server. APK tidak membawa database atau `.env`.

## Build APK lewat GitHub
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder ini.
3. Masuk tab **Actions**.
4. Jalankan **Build PRT CREATOR HUB APK** dengan **Run workflow**.
5. Setelah selesai, buka hasil workflow → **Artifacts** → `PRT-CREATOR-HUB-debug-apk`.
6. Download `app-debug.apk` dan install di Android.

Workflow juga otomatis build saat push ke `main` atau `master`.

## Identitas Android
- App name: PRT CREATOR HUB
- Package ID: `com.paprandomteam.prtcreatorhub`
- HTTPS only
- Cleartext traffic disabled
- Debug APK untuk testing

## Produksi
Untuk Play Store/production, tambahkan keystore signing melalui GitHub Secrets dan ubah workflow menjadi signed release APK/AAB. Jangan commit keystore, password, `.env`, Google credentials, API keys, atau session secrets.

## Catatan
Ini adalah shell Android untuk web PRT. Karena backend tetap berada di server, aplikasi membutuhkan koneksi ke server PRT.
